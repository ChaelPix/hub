==========
Récurrence
==========

.. toctree::
   :maxdepth: 1

Peu important pour le moment...