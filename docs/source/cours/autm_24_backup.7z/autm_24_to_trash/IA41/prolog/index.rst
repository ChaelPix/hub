======
Prolog
======

Installation :

.. code-block:: sh

        sudo apt-get install swi-prolog
        swipl


.. toctree::
   :maxdepth: 1

   toolbox/bases
   toolbox/comparaison
   toolbox/raisonner